@extends('layout.app')

@section('content')

<div id="page-content-wrapper">
    <!-- Top navigation-->
  

    <!-- Page content-->
    <div class="container-fluid">
        <h1 class="mt-4">Selamat Datang di Halaman Admin WEB RESTAURANT</h1>
        <p>
            Silahkan Mengatur tampilan dan manajemen dari web restaurant
        </p>
    </div>
</div>

@endsection