@if(Auth::check() && Auth::user()->username == "Admin")
<div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="border-end bg-white" id="sidebar-wrapper">
               
                <div class="list-group list-group-flush">
                    <a
                        class="list-group-item list-group-item-action list-group-item-light p-3"
                        href="{{ route('admin.dashboard') }}"
                        >Dashboard</a
                    >
                    <a
                        class="list-group-item list-group-item-action list-group-item-light p-3"
                        href="{{ route('admin.daftarmakanan') }}"
                        >Daftar Makanan</a
                    >
                   <a
                        class="list-group-item list-group-item-action list-group-item-light p-3"
                        href="{{ route('admin.pembayaran') }}"
                        >Pembayaran</a
                    >
                    <a
                        class="list-group-item list-group-item-action list-group-item-light p-3"
                        href="{{ route('admin.laporan') }}"
                        >Laporan Penjualan</a
                    >
                </div>
            </div>
            <!-- Page content wrapper-->
            @endif

