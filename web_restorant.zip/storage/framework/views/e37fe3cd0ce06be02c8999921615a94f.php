<?php if(Auth::check() && Auth::user()->username == "Admin"): ?>
<div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="border-end bg-white" id="sidebar-wrapper">
               
                <div class="list-group list-group-flush">
                    <a
                        class="list-group-item list-group-item-action list-group-item-light p-3"
                        href="<?php echo e(route('admin.dashboard')); ?>"
                        >Dashboard</a
                    >
                    <a
                        class="list-group-item list-group-item-action list-group-item-light p-3"
                        href="<?php echo e(route('admin.daftarmakanan')); ?>"
                        >Daftar Makanan</a
                    >
                   <a
                        class="list-group-item list-group-item-action list-group-item-light p-3"
                        href="<?php echo e(route('admin.pembayaran')); ?>"
                        >Pembayaran</a
                    >
                    <a
                        class="list-group-item list-group-item-action list-group-item-light p-3"
                        href="<?php echo e(route('admin.laporan')); ?>"
                        >Laporan Penjualan</a
                    >
                </div>
            </div>
            <!-- Page content wrapper-->
            <?php endif; ?>

<?php /**PATH D:\SEMESTER 3\#61 web programming\baru\restoranyanto\resources\views/layout/partial/sidebar.blade.php ENDPATH**/ ?>