<?php $__env->startSection('content'); ?>

<div id="page-content-wrapper">
    <!-- Top navigation-->
  

    <!-- Page content-->
    <div class="container-fluid">
        <h1 class="mt-4">Selamat Datang di Halaman Admin WEB RESTAURANT</h1>
        <p>
            Silahkan Mengatur tampilan dan manajemen dari web restaurant
        </p>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 3\#61 web programming\baru\restoranyanto\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>