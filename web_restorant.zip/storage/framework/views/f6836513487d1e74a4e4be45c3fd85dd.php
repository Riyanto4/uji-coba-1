        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="border-end bg-white" id="sidebar-wrapper">
               
                <div class="list-group list-group-flush">
                    <a
                        class="list-group-item list-group-item-action list-group-item-light p-3"
                        href="<?php echo e(route('admin.dashboard')); ?>"
                        >Dashboard</a
                    >
                    <a
                        class="list-group-item list-group-item-action list-group-item-light p-3"
                        href="<?php echo e(route('admin.daftarmakanan')); ?>"
                        >Daftar Makanan</a
                    >
                                       <a
                        class="list-group-item list-group-item-action list-group-item-light p-3"
                        href="<?php echo e(route('admin.pembayaran')); ?>"
                        >Pembayaran</a
                    >
                   
                </div>
            </div>
            <!-- Page content wrapper-->

<?php /**PATH D:\pemesanan_restoran\restoranyanto\resources\views/layout/partial/sidebar.blade.php ENDPATH**/ ?>