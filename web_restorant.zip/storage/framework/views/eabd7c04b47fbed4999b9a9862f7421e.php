<?php $__env->startSection('content'); ?>


<div id="page-content-wrapper">
    <div class="container-fluid">
        <h1 class="mt-4">Daftar Makanan</h1>
        
        <a href="<?php echo e(route('admin.daftarmakanan.create')); ?>" class="btn btn-primary">Tambah Makanan</a>

        <table class="table table-bordered mt-3">
            <thead class="thead-dark">
                <tr>
                    <th>Nama Menu</th>
                    <th>Harga</th>
                    <th>Kategori</th>
                    <th>Deskripsi</th>
                    <th>Gambar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($menu->nama_menu); ?></td>
                        <td><?php echo e($menu->harga); ?></td>
                        <td><?php echo e($menu->kategori); ?></td>
                        <td><?php echo e($menu->deskripsi); ?></td>
                        <td>
                            <!-- Menampilkan gambar menggunakan tag img -->
                            <img src="<?php echo e(asset('foto/' . $menu->image)); ?>" alt="<?php echo e($menu->nama_menu); ?>" style="max-width: 100px;">
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.daftarmakanan.edit', $menu->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                            <form action="<?php echo e(route('admin.daftarmakanan.destroy', $menu->id)); ?>" method="post" style="display: inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus menu ini?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 3\#61 web programming\baru\restoranyanto\resources\views/admin/daftar_makanan/index.blade.php ENDPATH**/ ?>