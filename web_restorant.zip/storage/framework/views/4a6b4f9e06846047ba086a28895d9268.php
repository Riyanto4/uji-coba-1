<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <h2 class="mb-4">Menu Makanan</h2>
    <div class="row">
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <!-- Ganti URL gambar dengan path sesuai dengan struktur penyimpanan gambar Anda -->
                    <img src="<?php echo e(asset('foto/' . $menu->image)); ?>" class="card-img-top" alt="<?php echo e($menu->nama_menu); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($menu->nama_menu); ?></h5>
                        <p class="card-text"><?php echo e($menu->deskripsi); ?></p>
                        <p class="card-text">Rp. <?php echo e($menu->harga); ?></p>
                        <a href="<?php echo e(route('menu.addToCart', ['id' => $menu->id])); ?>" class="btn btn-primary">Pesan Sekarang</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 3\#61 web programming\web_restorant\restoranyanto\resources\views/web/home.blade.php ENDPATH**/ ?>