<?php $__env->startSection('content'); ?>


<div id="page-content-wrapper">
    <div class="container-fluid">
        <h1 class="mt-4">Edit Makanan</h1>

        <form action="<?php echo e(route('admin.daftarmakanan.update', $menu->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group my-2">
                <label for="nama_menu">Nama Menu</label>
                <input type="text" class="form-control" id="nama_menu" name="nama_menu" value="<?php echo e($menu->nama_menu); ?>" required>
            </div>

            <div class="form-group my-2">
                <label for="harga">Harga</label>
                <input type="text" class="form-control" id="harga" name="harga" value="<?php echo e($menu->harga); ?>" required>
            </div>

            <div class="form-group my-2">
                <label for="kategori">Kategori</label>
                <select class="form-control" id="kategori" name="kategori" required>
                    <option value="makanan" <?php echo e($menu->kategori == 'makanan' ? 'selected' : ''); ?>>Makanan</option>
                    <option value="minuman" <?php echo e($menu->kategori == 'minuman' ? 'selected' : ''); ?>>Minuman</option>
                </select>
            </div>

            <div class="form-group my-2">
                <label for="deskripsi">Deskripsi</label>
                <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" required><?php echo e($menu->deskripsi); ?></textarea>
            </div>

            <div class="form-group my-2 form-control">
                <label for="gambar">Gambar </label>
                <input type="file" class="form-control-file" id="gambar" name="gambar">
            </div>

            <!-- Tampilkan gambar saat ini -->
            <div class="form-group my-2">
                <label for="current_image">Gambar saat ini:</label>
                <img src="<?php echo e(asset('foto/' . $menu->image)); ?>" alt="<?php echo e($menu->nama_menu); ?>" style="max-width: 200px;">
            </div>

            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 3\#61 web programming\baru\restoranyanto\resources\views/admin/daftar_makanan/edit.blade.php ENDPATH**/ ?>