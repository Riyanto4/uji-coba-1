

<?php $__env->startSection('content'); ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama User</th>
                <th>Total Harga</th>
                <th>Tanggal Transaksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $laporanData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($laporan->nama_user); ?></td>
                    <td>Rp. <?php echo e($laporan->total_harga); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($laporan->tanggal_transaksi)->format('d-m-Y')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 3\#61 web programming\pemesanan_restoran\restoranyanto\resources\views/admin/laporan/index.blade.php ENDPATH**/ ?>