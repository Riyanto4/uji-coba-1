<?php $__env->startSection('content'); ?>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>No.</th>
            <th>Nama User</th>
            <th>Total Harga</th>
            <th>Aksi</th> 
        </tr>
    </thead>
    <tbody>
        <?php
            $totalHarga = 0;
        ?>

        <?php $__currentLoopData = $daftarPesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($pesanan->username); ?></td>
                <td>Rp. <?php echo e($pesanan->total_harga); ?></td>
                <td>
                    <form action="<?php echo e(route('verifikasi.pembayaran', ['userId' => $pesanan->user_id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary btn-sm">Verifikasi Pembayaran</button>
                    </form>
                </td>
            </tr>
            <?php
                $totalHarga += $pesanan->total_harga;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 3\#61 web programming\pemesanan_restoran\restoranyanto\resources\views/admin/pembayaran/index.blade.php ENDPATH**/ ?>