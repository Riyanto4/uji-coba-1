<?php $__env->startSection('content'); ?>
   

    <div class="container mt-4">
        <h2>Daftar Pesanan</h2>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Nama Menu</th>
                    <th>Quantity</th>
                    <th>Harga</th>
                    <th>Total Harga</th>
                    <th>Aksi</th> <!-- Kolom untuk tombol tambah dan kurang -->
                </tr>
            </thead>
            <tbody>
                <?php
                    $totalHarga = 0;
                ?>

                
                <?php $__currentLoopData = $daftarPesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($dataMenu[$index]->nama_menu); ?></td>
                        <td>
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <a href="<?php echo e(route('tambahQuantity', ['id' => $pesanan->id])); ?>" class="btn btn-primary btn-sm">+</a>
                                </span>
                                <input type="text" class="form-control" value="<?php echo e($pesanan->quantity); ?>" readonly>
                                <span class="input-group-btn">
                                    <a href="<?php echo e(route('kurangQuantity', ['id' => $pesanan->id])); ?>" class="btn btn-danger btn-sm">-</a>
                                </span>
                            </div>
                        </td>
                        <td><?php echo e($dataMenu[$index]->harga); ?></td>
                        <td><?php echo e($pesanan->quantity * $dataMenu[$index]->harga); ?></td>
                        <?php
                            $totalHarga += $pesanan->quantity * $dataMenu[$index]->harga;
                        ?>
                        <td>
                            <a href="<?php echo e(route('hapusDaftarPesanan', ['index' => $index + 1])); ?>" class="btn btn-danger btn-sm">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="mt-3">
            <p>Total Harga yang Harus Dibayar di Kasir: <strong>Rp. <?php echo e($totalHarga); ?></strong></p>
        </div>

        <div class="d-flex justify-content-end">
        <button class="btn btn-success" onclick="showMessageSuccess()">PROSES</button> 
        </div>
    </div>

    <script>
        function     showMessageSuccess() {
            alert('Berhasil!. Pesanan sudah diproses.')
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 3\#61 web programming\baru\restoranyanto\resources\views/web/daftar_pesanan.blade.php ENDPATH**/ ?>